//
//  cardSelectionViewController.swift
//  Tarot
//
//  Created by Emre Demirkol on 22.02.2018.
//  Copyright © 2018 Emre Demirkol. All rights reserved.
//

import UIKit

class cardSelectionViewController: UIViewController {
    
    var langFlag : Bool = false
    var selectedCardCount : Int = 7
    
    @IBOutlet weak var cardButton_1: UIButton!
    @IBOutlet weak var cardButton_2: UIButton!
    @IBOutlet weak var cardButton_3: UIButton!
    @IBOutlet weak var cardButton_4: UIButton!
    @IBOutlet weak var cardButton_5: UIButton!
    @IBOutlet weak var cardButton_6: UIButton!
    @IBOutlet weak var cardButton_7: UIButton!
    @IBOutlet weak var cardButton_8: UIButton!
    @IBOutlet weak var cardButton_9: UIButton!
    @IBOutlet weak var cardButton_10: UIButton!
    @IBOutlet weak var cardButton_11: UIButton!
    @IBOutlet weak var cardButton_12: UIButton!
    @IBOutlet weak var cardButton_13: UIButton!
    @IBOutlet weak var cardButton_14: UIButton!
    @IBOutlet weak var cardButton_15: UIButton!
    @IBOutlet weak var cardButton_16: UIButton!
    @IBOutlet weak var cardButton_17: UIButton!
    @IBOutlet weak var cardButton_18: UIButton!
    @IBOutlet weak var cardButton_19: UIButton!
    @IBOutlet weak var cardButton_20: UIButton!
    @IBOutlet weak var cardButton_21: UIButton!
    @IBOutlet weak var cardButton_22: UIButton!
    @IBOutlet weak var cardButton_23: UIButton!
    @IBOutlet weak var cardButton_24: UIButton!
    @IBOutlet weak var cardButton_25: UIButton!
    @IBOutlet weak var cardButton_26: UIButton!
    @IBOutlet weak var cardButton_27: UIButton!
    @IBOutlet weak var cardButton_28: UIButton!
    @IBOutlet weak var cardButton_29: UIButton!
    @IBOutlet weak var cardButton_30: UIButton!
    @IBOutlet weak var cardButton_31: UIButton!
    @IBOutlet weak var cardButton_32: UIButton!
    @IBOutlet weak var cardButton_33: UIButton!
    @IBOutlet weak var cardButton_34: UIButton!
    @IBOutlet weak var cardButton_35: UIButton!
    @IBOutlet weak var cardButton_36: UIButton!
    @IBOutlet weak var cardButton_37: UIButton!
    @IBOutlet weak var cardButton_38: UIButton!
    @IBOutlet weak var cardButton_39: UIButton!
    @IBOutlet weak var cardButton_40: UIButton!
    @IBOutlet weak var cardButton_41: UIButton!
    @IBOutlet weak var cardButton_42: UIButton!
    @IBOutlet weak var cardButton_43: UIButton!
    @IBOutlet weak var cardButton_44: UIButton!
    @IBOutlet weak var cardButton_45: UIButton!
    @IBOutlet weak var cardButton_46: UIButton!
    @IBOutlet weak var cardButton_47: UIButton!
    @IBOutlet weak var cardButton_48: UIButton!
    @IBOutlet weak var cardButton_49: UIButton!
    @IBOutlet weak var cardButton_50: UIButton!
    @IBOutlet weak var cardButton_51: UIButton!
    @IBOutlet weak var cardButton_52: UIButton!
    @IBOutlet weak var cardButton_53: UIButton!
    @IBOutlet weak var cardButton_54: UIButton!
    @IBOutlet weak var cardButton_55: UIButton!
    @IBOutlet weak var cardButton_56: UIButton!
    @IBOutlet weak var cardButton_57: UIButton!
    @IBOutlet weak var cardButton_58: UIButton!
    @IBOutlet weak var cardButton_59: UIButton!
    @IBOutlet weak var cardButton_60: UIButton!
    @IBOutlet weak var cardButton_61: UIButton!
    @IBOutlet weak var cardButton_62: UIButton!
    @IBOutlet weak var cardButton_63: UIButton!
    @IBOutlet weak var cardButton_64: UIButton!
    @IBOutlet weak var cardButton_65: UIButton!
    @IBOutlet weak var cardButton_66: UIButton!
    @IBOutlet weak var cardButton_67: UIButton!
    @IBOutlet weak var cardButton_68: UIButton!
    @IBOutlet weak var cardButton_69: UIButton!
    @IBOutlet weak var cardButton_70: UIButton!
    @IBOutlet weak var cardButton_71: UIButton!
    @IBOutlet weak var cardButton_72: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    func counterDecAndCheck()
    {
        selectedCardCount = selectedCardCount - 1
        if selectedCardCount == 0
        {
            performSegue(withIdentifier: "selectedPassPage", sender: self)
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let firstPassPage = segue.destination as! selectedCardsViewController
        firstPassPage.langFlag = langFlag
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    @IBAction func cardSelection_1(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_2(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_3(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_4(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_5(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_6(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_7(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_8(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_9(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_10(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_11(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_12(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_13(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_14(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_15(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_16(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_17(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_18(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_19(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_20(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_21(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_22(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_23(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_24(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_25(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_26(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_27(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_28(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_29(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_30(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_31(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_32(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_33(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_34(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_35(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_36(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_37(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_38(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_39(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_40(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_41(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_42(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_43(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_44(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_45(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_46(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_47(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_48(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_49(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_50(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_51(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_52(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_53(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_54(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_55(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_56(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_57(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_58(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_59(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_60(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_61(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_62(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_63(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_64(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_65(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_66(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_67(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_68(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_69(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_70(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_71(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
    @IBAction func cardSelection_72(_ sender: UIButton) {
        sender.isHidden = true
        counterDecAndCheck()
    }
}














