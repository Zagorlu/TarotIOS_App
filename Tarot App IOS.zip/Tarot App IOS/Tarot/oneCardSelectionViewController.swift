//
//  oneCardSelectionViewController.swift
//  Tarot
//
//  Created by Emre Demirkol on 1.03.2018.
//  Copyright © 2018 Emre Demirkol. All rights reserved.
//

import UIKit

class oneCardSelectionViewController: UIViewController {
    
    var langFlag : Bool = false

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func passExpPage()
    {
        performSegue(withIdentifier: "oneCardExpPassPage", sender: self)
    }
    
    @IBAction func button_1(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_2(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_3(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_4(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_5(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_6(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_7(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_8(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_9(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_10(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_11(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_12(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_13(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_14(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_15(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_16(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_17(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_18(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_19(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_20(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_21(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_22(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_23(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_24(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_25(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_26(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_27(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_28(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_29(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_30(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_31(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_32(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_33(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_34(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_35(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_36(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_37(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_38(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_39(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_40(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_41(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_42(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_43(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_44(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_45(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_46(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_47(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_48(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_49(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_50(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_51(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_52(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_53(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_54(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_55(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_56(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_57(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_58(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_59(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_60(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_61(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_62(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_63(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_64(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_65(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_66(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_67(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_68(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_69(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_70(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_71(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    @IBAction func button_72(_ sender: UIButton) {
        sender.isHidden = true
        passExpPage()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let firstPassPage = segue.destination as! oneCardExpViewController
        firstPassPage.langFlag = langFlag
    }
}
