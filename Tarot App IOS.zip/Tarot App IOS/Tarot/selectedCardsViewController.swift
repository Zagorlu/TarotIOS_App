//
//  selectedCardsViewController.swift
//  Tarot
//
//  Created by Emre Demirkol on 24.02.2018.
//  Copyright © 2018 Emre Demirkol. All rights reserved.
//

import UIKit

class selectedCardsViewController: UIViewController {
    
    var langFlag : Bool = false

    @IBOutlet weak var descLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if langFlag == false
        {
            descLabel.text = "Your chosen cards are being interpreted, please wait. You can read the comments by clicking on the cards that are opened ..."
        }
        else
        {
            descLabel.text = "Seçtiğiniz kartlarınız yorumlanıyor, lütfen bekleyiniz. Açılan kartlarınızın üzerine tıklayarak yorumları okuyabilirsiniz..."
        }
        descLabel.textColor = UIColor.white
        descLabel.sizeToFit()
        descLabel.lineBreakMode = .byWordWrapping
        descLabel.numberOfLines = 0
        descLabel.textAlignment = NSTextAlignment.center;
        descLabel.font.withSize(32)
        descLabel.backgroundColor = UIColor.init(white: 0, alpha: 0.8)
        
    }
    

    override func viewDidAppear(_ animated: Bool) {
        sleep(5)
        performSegue(withIdentifier: "tablePassPage", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let firstPassPage = segue.destination as! selectedTableViewController
        firstPassPage.langFlag = langFlag
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }


}
