//
//  selectedTableViewController.swift
//  Tarot
//
//  Created by Emre Demirkol on 24.02.2018.
//  Copyright © 2018 Emre Demirkol. All rights reserved.
//

import UIKit

class cardValues {
    var cardId:String = ""
    var imageName:String = ""
    var cardName:String = ""
    var description: String = ""
}

class selectedTableViewController: UIViewController,XMLParserDelegate {
    
    var langFlag : Bool = false
    var isFirstValue : Bool = true
    var parser = XMLParser()
    
    var bufferCard = cardValues()
    var cardsArray = [cardValues]()
    var foundCharacters = "";
    var randomSelectedCards = [Int]()
    var globIndex:Int = 0

    @IBOutlet weak var chooseAgainButton: UIButton!
    @IBOutlet weak var menuButton: UIButton!
    
    @IBOutlet weak var button_0: UIButton!
    @IBOutlet weak var button_1: UIButton!
    @IBOutlet weak var button_2: UIButton!
    @IBOutlet weak var button_3: UIButton!
    @IBOutlet weak var button_4: UIButton!
    @IBOutlet weak var button_5: UIButton!
    @IBOutlet weak var button_6: UIButton!
    
    
    func setRandomNumbers()
    {
        if isFirstValue
        {
            while  randomSelectedCards.count != 7
            {
                let randomNumber = Int(arc4random_uniform(78))
                if !randomSelectedCards.contains(randomNumber)
                {
                    randomSelectedCards.append(randomNumber)
                }
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if langFlag == false
        {
            chooseAgainButton.setImage(UIImage(named: "chooseAgain_eng.png"), for: .normal)
        }
        else
        {
            chooseAgainButton.setImage(UIImage(named: "chooseAgain_tr.png"), for: .normal)
        }
        
        chooseAgainButton.layer.cornerRadius = 10
        chooseAgainButton.layer.borderWidth = 2
        chooseAgainButton.backgroundColor = UIColor.init(white: 1, alpha: 0.8)
        
        menuButton.layer.cornerRadius = 10
        menuButton.layer.borderWidth = 2
        menuButton.backgroundColor = UIColor.init(white: 1, alpha: 0.8)
        
        
        if langFlag == false
        {
            if let filepath = Bundle.main.path(forResource: "cards_info_eng", ofType: "xml")
            {
                do
                {
                    let contents = try String(contentsOfFile: filepath)
                    let xmlData = contents.data(using: String.Encoding.utf8)!
                    self.parser = XMLParser(data: xmlData)
                    self.parser.delegate = self
                    if (parser.parse())
                    {
                        setRandomNumbers()
                        button_0.setImage(UIImage(named: cardsArray[randomSelectedCards[0]].imageName), for: .normal)
                        button_1.setImage(UIImage(named: cardsArray[randomSelectedCards[1]].imageName), for: .normal)
                        button_2.setImage(UIImage(named: cardsArray[randomSelectedCards[2]].imageName), for: .normal)
                        button_3.setImage(UIImage(named: cardsArray[randomSelectedCards[3]].imageName), for: .normal)
                        button_4.setImage(UIImage(named: cardsArray[randomSelectedCards[4]].imageName), for: .normal)
                        button_5.setImage(UIImage(named: cardsArray[randomSelectedCards[5]].imageName), for: .normal)
                        button_6.setImage(UIImage(named: cardsArray[randomSelectedCards[6]].imageName), for: .normal)
                        
                    }
                    else
                    {
                        
                        print("XML not parsed !!!")
                    }
                }
                catch
                {
                    print("File Does not Opened !!!")
                }
            }
        }
        else
        {
            if let filepath = Bundle.main.path(forResource: "cards_info_tr", ofType: "xml")
            {
                do
                {
                    let contents = try String(contentsOfFile: filepath)
                    let xmlData = contents.data(using: String.Encoding.utf8)!
                    self.parser = XMLParser(data: xmlData)
                    self.parser.delegate = self
                    if (parser.parse())
                    {
                        setRandomNumbers()
                        button_0.setImage(UIImage(named: cardsArray[randomSelectedCards[0]].imageName), for: .normal)
                        button_1.setImage(UIImage(named: cardsArray[randomSelectedCards[1]].imageName), for: .normal)
                        button_2.setImage(UIImage(named: cardsArray[randomSelectedCards[2]].imageName), for: .normal)
                        button_3.setImage(UIImage(named: cardsArray[randomSelectedCards[3]].imageName), for: .normal)
                        button_4.setImage(UIImage(named: cardsArray[randomSelectedCards[4]].imageName), for: .normal)
                        button_5.setImage(UIImage(named: cardsArray[randomSelectedCards[5]].imageName), for: .normal)
                        button_6.setImage(UIImage(named: cardsArray[randomSelectedCards[6]].imageName), for: .normal)
                    }
                    else
                    {
                        
                        print("XML not parsed !!!")
                    }
                }
                catch
                {
                    print("File Does not Opened !!!")
                }
            }
        }
    }
    
    func setGlobalValues(index: Int)
    {
        self.globIndex = index
        performSegue(withIdentifier: "expPassPage", sender: self)
    }
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String]) {
        
        if elementName=="card"
        {
            if let id = attributeDict["id"]
            {
                bufferCard.cardId = id
            }
            if let imageName = attributeDict["imageName"]
            {
                bufferCard.imageName = imageName
            }
            if let figureName = attributeDict["figureName"]
            {
                bufferCard.cardName = figureName
            }
            if let commentText = attributeDict["commentText"]
            {
                bufferCard.description = commentText
            }
        }
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        
        if elementName == "card" {
            let tempItem = cardValues();
            tempItem.cardId = self.bufferCard.cardId;
            tempItem.cardName = self.bufferCard.cardName;
            tempItem.description = self.bufferCard.description;
            tempItem.imageName = self.bufferCard.imageName;
            self.cardsArray.append(tempItem);
        }
        self.foundCharacters = ""
    }
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        self.foundCharacters += string;
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    @IBAction func tryAgain(_ sender: UIButton) {
        performSegue(withIdentifier: "tryAgain", sender: self)
    }
    @IBAction func returnMenu(_ sender: UIButton) {
        performSegue(withIdentifier: "returnMenu", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destController = segue.destination as? ViewController {
            destController.langFlag = langFlag
        }
        
        if let destController = segue.destination as? cardSelectionViewController {
            destController.langFlag = langFlag
        }
        
        if let destController = segue.destination as? ViewController {
            destController.langFlag = langFlag
        }
        
        if let destController = segue.destination as? explainationViewController {
            destController.langFlag = langFlag
            destController.index = globIndex
            destController.cardsArray = cardsArray
            destController.randomSelectedCards = randomSelectedCards
        }
    }
    
    @IBAction func cardButton_0(_ sender: UIButton) {
        setGlobalValues(index: 2)
    }
    @IBAction func cardButton_1(_ sender: UIButton) {
        setGlobalValues(index: 0)
    }
    @IBAction func cardButton_2(_ sender: UIButton) {
        setGlobalValues(index: 1)
    }
    @IBAction func cardButton_3(_ sender: UIButton) {
        setGlobalValues(index: 3)
    }
    @IBAction func cardButton_4(_ sender: UIButton) {
        setGlobalValues(index: 5)
    }
    @IBAction func cardButton_5(_ sender: UIButton) {
        setGlobalValues(index: 4)
    }
    @IBAction func cardButton(_ sender: UIButton) {
        setGlobalValues(index: 6)
    }
}
