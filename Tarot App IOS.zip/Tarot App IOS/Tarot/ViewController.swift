//
//  ViewController.swift
//  Tarot
//
//  Created by Emre Demirkol on 22.02.2018.
//  Copyright © 2018 Emre Demirkol. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var langFlag : Bool = false
    var m_cornerRadius : CGFloat = 10
    var m_borderWidth : CGFloat = 2
    var m_aplfaValue : CGFloat = 0.8
    
    @IBOutlet weak var startButton: UIButton!
    @IBOutlet weak var langButton: UIButton!
    @IBOutlet weak var oneCardButton: UIButton!
    @IBOutlet weak var aboutButton: UIButton!
    @IBOutlet weak var exitButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if langFlag == false
        {
            startButton.setImage(UIImage(named: "start_eng.png"), for: .normal)
            langButton.setImage(UIImage(named: "change_eng.png"), for: .normal)
            oneCardButton.setImage(UIImage(named: "one_eng.png"), for: .normal)
            aboutButton.setImage(UIImage(named: "about_eng.png"), for: .normal)
            exitButton.setImage(UIImage(named: "exit_eng.png"), for: .normal)
        }
        else
        {
            startButton.setImage(UIImage(named: "start_tr.png"), for: .normal)
            langButton.setImage(UIImage(named: "change_tr.png"), for: .normal)
            oneCardButton.setImage(UIImage(named: "one_tr.png"), for: .normal)
            aboutButton.setImage(UIImage(named: "about_tr.png"), for: .normal)
            exitButton.setImage(UIImage(named: "exit_tr.png"), for: .normal)
        }
        //startButton.backgroundColor = UIColor.white
        //langButton.backgroundColor = UIColor.white
        
        //startButton.backgroundColor = UIColor.init(red: 255, green: 255, blue: 255, alpha: 0.5)
        //langButton.backgroundColor = UIColor.init(red: 255, green: 255, blue: 255, alpha: 15)
        
        oneCardButton.layer.cornerRadius = m_cornerRadius
        oneCardButton.layer.borderWidth = m_borderWidth
        
        startButton.layer.cornerRadius = m_cornerRadius
        startButton.layer.borderWidth = m_borderWidth
        
        langButton.layer.cornerRadius = m_cornerRadius
        langButton.layer.borderWidth = m_borderWidth
        
        aboutButton.layer.cornerRadius = m_cornerRadius
        aboutButton.layer.borderWidth = m_borderWidth
        
        exitButton.layer.cornerRadius = m_cornerRadius
        exitButton.layer.borderWidth = m_borderWidth
        
        startButton.backgroundColor = UIColor.init(white: 1, alpha: m_aplfaValue)
        langButton.backgroundColor = UIColor.init(white: 1, alpha: m_aplfaValue)
        oneCardButton.backgroundColor = UIColor.init(white: 1, alpha: m_aplfaValue)
        aboutButton.backgroundColor = UIColor.init(white: 1, alpha: m_aplfaValue)
        exitButton.backgroundColor = UIColor.init(white: 1, alpha: m_aplfaValue)
        
        
        startButton.center = self.view.center
        langButton.center = self.view.center
        oneCardButton.center = self.view.center
        aboutButton.center = self.view.center
        exitButton.center = self.view.center
        
        self.view.addSubview(startButton)
        self.view.addSubview(langButton)
        self.view.addSubview(oneCardButton)
        self.view.addSubview(aboutButton)
        self.view.addSubview(exitButton)
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    @IBAction func startTarot(_ sender: UIButton) {
        //dismiss(animated: true, completion: nil)
        performSegue(withIdentifier: "fisrtPassPage", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let destController = segue.destination as? firstPassViewController {
            destController.langFlag = langFlag
        }
        
        if let destController = segue.destination as? oneCardSelectionViewController {
            destController.langFlag = langFlag
        }
        
        
        if let destController = segue.destination as? aboutUsViewController {
            destController.langFlag = langFlag
        }
        
        /*
        if let destController = segue.destination as? explainationViewController {
            destController.langFlag = langFlag
            destController.index = globIndex
            destController.cardsArray = cardsArray
            destController.randomSelectedCards = randomSelectedCards
        }
        */
    }
    
    @IBAction func oneTarot(_ sender: UIButton) {
        performSegue(withIdentifier: "onePassPage", sender: self)
    }
    
    @IBAction func changeLang(_ sender: UIButton) {
        //dismiss(animated: true, completion: nil)
        if langFlag == false
        {
            langFlag = true
        }
        else
        {
            langFlag = false
        }
        viewDidLoad()
    }
    @IBAction func aboutUs(_ sender: UIButton) {
        performSegue(withIdentifier: "aboutUsPassPage", sender: self)
    }
    
    @IBAction func exitProgram(_ sender: UIButton) {
        //dismiss(animated: true, completion: nil)
        exit(0)
    }
}

