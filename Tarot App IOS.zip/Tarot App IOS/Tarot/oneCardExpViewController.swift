//
//  oneCardExpViewController.swift
//  Tarot
//
//  Created by Emre Demirkol on 1.03.2018.
//  Copyright © 2018 Emre Demirkol. All rights reserved.
//

import UIKit

class oneCardExpViewController: UIViewController, XMLParserDelegate {

    var langFlag : Bool = false
    var parser = XMLParser()
    var bufferCard = cardValues()
    var cardsArray = [cardValues]()
    var foundCharacters = "";
    var globIndex:Int = 0
    var randomCard : Int = 0
    
    
    @IBOutlet weak var cardNameLabel: UILabel!
    @IBOutlet weak var imageBackground: UIImageView!
    @IBOutlet weak var shortImage: UIImageView!
    @IBOutlet weak var descriptionLabel: UITextView!
    
    @IBOutlet weak var menuButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        menuButton.layer.cornerRadius = 10
        menuButton.layer.borderWidth = 2
        menuButton.backgroundColor = UIColor.init(white: 1, alpha: 0.8)
        self.randomCard = Int(arc4random_uniform(78))
        
        
        if langFlag == false
        {
            if let filepath = Bundle.main.path(forResource: "cards_info_eng", ofType: "xml")
            {
                do
                {
                    let contents = try String(contentsOfFile: filepath)
                    let xmlData = contents.data(using: String.Encoding.utf8)!
                    self.parser = XMLParser(data: xmlData)
                    self.parser.delegate = self
                    if (parser.parse())
                    {
                        self.imageBackground.image = UIImage(named: cardsArray[randomCard].imageName)
                        self.shortImage.image = UIImage(named: cardsArray[randomCard].imageName)
                        cardNameLabel.text = cardsArray[randomCard].cardName
                        descriptionLabel.text = cardsArray[randomCard].description
                        
                        //cardNameLabel.sizeToFit()
                        //cardNameLabel.lineBreakMode = .byWordWrapping
                        //cardNameLabel.numberOfLines = 0
                        cardNameLabel.textAlignment = NSTextAlignment.center;
                        cardNameLabel.font.withSize(32)
                        cardNameLabel.layer.cornerRadius = 3
                        cardNameLabel.layer.borderWidth = 2
                        cardNameLabel.backgroundColor = UIColor.init(white: 1, alpha: 0.8)
                        cardNameLabel.font = UIFont(name:"HelveticaNeue-Bold", size: 20.0)

                        
                        //descriptionLabel.sizeToFit()
                        //descriptionLabel.textAlignment = NSTextAlignment.center;
                        descriptionLabel.layer.cornerRadius = 3
                        descriptionLabel.layer.borderWidth = 2
                        descriptionLabel.backgroundColor = UIColor.init(white: 1, alpha: 0.8)
                        descriptionLabel.font = UIFont(name:"HelveticaNeue-Bold", size: 16.0)

                    }
                    else
                    {
                        print("XML not parsed !!!")
                    }
                }
                catch
                {
                    print("File Does not Opened !!!")
                }
            }
        }
        else
        {
            if let filepath = Bundle.main.path(forResource: "cards_info_tr", ofType: "xml")
            {
                do
                {
                    let contents = try String(contentsOfFile: filepath)
                    let xmlData = contents.data(using: String.Encoding.utf8)!
                    self.parser = XMLParser(data: xmlData)
                    self.parser.delegate = self
                    if (parser.parse())
                    {
                        self.imageBackground.image = UIImage(named: cardsArray[randomCard].imageName)
                        self.shortImage.image = UIImage(named: cardsArray[randomCard].imageName)
                        cardNameLabel.text = cardsArray[randomCard].cardName
                        descriptionLabel.text = cardsArray[randomCard].description
                        
                        //cardNameLabel.sizeToFit()
                        //cardNameLabel.lineBreakMode = .byWordWrapping
                        //cardNameLabel.numberOfLines = 0
                        cardNameLabel.textAlignment = NSTextAlignment.center;
                        cardNameLabel.font.withSize(32)
                        cardNameLabel.layer.cornerRadius = 3
                        cardNameLabel.layer.borderWidth = 2
                        cardNameLabel.backgroundColor = UIColor.init(white: 1, alpha: 0.8)
                        cardNameLabel.font = UIFont(name:"HelveticaNeue-Bold", size: 20.0)

                        
                        //descriptionLabel.sizeToFit()
                        //descriptionLabel.textAlignment = NSTextAlignment.center;
                        descriptionLabel.layer.cornerRadius = 3
                        descriptionLabel.layer.borderWidth = 2
                        descriptionLabel.backgroundColor = UIColor.init(white: 1, alpha: 0.8)
                        descriptionLabel.font = UIFont(name:"HelveticaNeue-Bold", size: 16.0)

                    }
                    else
                    {
                        print("XML not parsed !!!")
                    }
                }
                catch
                {
                    print("File Does not Opened !!!")
                }
            }
        }
    }
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String]) {
        
        if elementName=="card"
        {
            if let id = attributeDict["id"]
            {
                bufferCard.cardId = id
            }
            if let imageName = attributeDict["imageName"]
            {
                bufferCard.imageName = imageName
            }
            if let figureName = attributeDict["figureName"]
            {
                bufferCard.cardName = figureName
            }
            if let commentText = attributeDict["commentText"]
            {
                bufferCard.description = commentText
            }
        }
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        
        if elementName == "card" {
            let tempItem = cardValues();
            tempItem.cardId = self.bufferCard.cardId;
            tempItem.cardName = self.bufferCard.cardName;
            tempItem.description = self.bufferCard.description;
            tempItem.imageName = self.bufferCard.imageName;
            self.cardsArray.append(tempItem);
        }
        self.foundCharacters = ""
    }
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        self.foundCharacters += string;
    }

    
    @IBAction func menuReturnButton(_ sender: UIButton) {
        performSegue(withIdentifier: "returnFirstPage", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let firstPassPage = segue.destination as! ViewController
        firstPassPage.langFlag = langFlag
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
