//
//  aboutUsViewController.swift
//  Tarot
//
//  Created by Emre Demirkol on 1.03.2018.
//  Copyright © 2018 Emre Demirkol. All rights reserved.
//

import UIKit

class aboutUsViewController: UIViewController {
    
    var m_cornerRadius : CGFloat = 10
    var m_borderWidth : CGFloat = 2
    var m_aplfaValue : CGFloat = 0.8
    
    @IBOutlet weak var backButton: UIButton!
    
    var langFlag : Bool = false
    
    @IBOutlet weak var textLabel: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        backButton.layer.cornerRadius = m_cornerRadius
        backButton.layer.borderWidth = m_borderWidth
        backButton.backgroundColor = UIColor.init(white: 1, alpha: m_aplfaValue)

        if langFlag
        {
            textLabel.text = "Birçok kişiye göre, gizem 'Tarot' sözcüğünde gizlidir; sözcüğün Eski Mısırca bir sözcük olan 'Ta-rosh'dan geldiği söylenir; 'Ta-rosh'un anlamı 'Kral Yolu'dur; Eski Mısır´ın Maji Tanrısı Thoth´u Tarot özdeşleştiren görüşler de vardır ve bu görüşe göre Tarot, Thoth´un tüm bilgeliğinin saklandığı kitaptır. Ve son bir diğer iddia sözcüğün Latince 'Rota' dan üretilmiş bir anagram yani şifre olduğudur; bu da çark anlamına gelir; yaşamın doğumdan ölüme sürekli dönen bir çark olduğunu simgeler. Bütün bunlar birer varsayımdır ve hiç kimse Tarot´un kesin kökenini bilmemektedir ve gizemciliğin temel inancında Tarot asla bir fal değildir. Özetle, falın nerede Tarot Oyunu ile bütünleştiği de bilinmemekte, ya da tam tersinin... Hemen hemen herşeyle fala bakılır; kurban edilmiş hayvanların dumanları tüten iç organları, gökyüzünde uçan kuşların oluşturduğu şekiller, renkli taşlar, yazı tura atmalar, kahve fincanı, su tası, zar vb... Uygulamanın temelinde, öncelikle ne olacağını önceden öğrenme arzusu ve daha incelikle bakıldığında ise herşeyin birbiriyle bağlantılı olduğu, herşeyin bir anlamı olduğu ve hiçbir şeyin rastlantı eseri gerçekleşmediği inancı vardır. Rastlantı kavramı gerçekte çok yenidir yani neden ve sonuçtur; iki olay arasındaki tek geçerli bağlantı olduğu öğretisinden doğar. Bu mantıksal bağlantının dışında kalan olaylar tesadüfi yani anlamsıdır. Artık, raslantılarda bir mantık veya matematiksel bir anlam aranmaktadır. Ama, daha önceleri, insanlar benzerliklere göre düşünürlerdi. Zodyak´ın yani gezegenlerin gök konumu haritasının yolu bir kişinin yaşamındaki yola benzetilirdi. Bir fincanın dibindeki çay yapraklarının şekli, bir savaşın çıkması olarak anlamlandırılır ve herşey birbirine bağlanırdı. Yani bir dizisel anlamsallık aranırdı. Bu düşünce, son zamanlarda, olayların seri halinde gerçekleşmesinden etkilenen bazı bilimadamları bile bu düşünceyi ciddiye almaya başlamışlardır."
            //textLabel.sizeToFit()
            //textLabel.textAlignment = NSTextAlignment.center;
            textLabel.layer.cornerRadius = m_cornerRadius
            textLabel.layer.borderWidth = m_borderWidth
            textLabel.backgroundColor = UIColor.init(white: 1, alpha: 0.8)
            textLabel.font = UIFont(name:"HelveticaNeue-Bold", size: 16.0)
        }
        else
        {
            textLabel.text = "For many, mystery is hidden in the word 'tarot'; is said to have come from an ancient Egyptian word 'Ta-rosh'; 'Ta-rosh means' King's Way'; There are also views that identify the ancient Egyptian Thoth, Thoth, with the Tarot, and according to this view, the Tarot is the book of all the wisdom of Thoth. And another last claim is that it is an anagram made of Latin 'Rota', that is, a password; this means the wheel; Symbols that life is a constantly rotating impulse to death from birth. All of this is hypothetical, and no one knows the exact origin of the Tarot, and the basic belief in your mysticism is that the Tarot is never a fortune. In a nutshell, it is also unknown where the fortune is integrated with the Tarot Game, or vice versa ... Almost everything is looked after; the shape of the birds flying in the sky, the colored stones, the tumbler, the coffee cup, the water cup, the dice, etc. ... On the basis of the application, the desire to know in advance what will happen first and, , there is a belief that everything has a meaning and that nothing happened by chance. The concept of coincidence is in fact very new, namely cause and effect; the only valid connection between the two events. The events outside this logical connection are coincidental, meaning meaningful. Now, rationality is looking for a logic or a mathematical meaning. But, earlier, people would think according to similarities. The path of the planet's sky position map of the zodiac resembled the path of one's life. The shape of the leaves of tea in the background of a cup was perceived as a war, and everything connected to each other. So a serial semantics would be sought. This idea has recently begun to be taken seriously by some scientists who are influenced by the series of events."
            //textLabel.sizeToFit()
            //textLabel.textAlignment = NSTextAlignment.center;
            textLabel.layer.cornerRadius = m_cornerRadius
            textLabel.layer.borderWidth = m_borderWidth
            textLabel.backgroundColor = UIColor.init(white: 1, alpha: 0.8)
            textLabel.font = UIFont(name:"HelveticaNeue-Bold", size: 16.0)
        }
    }

    @IBAction func returnButton(_ sender: UIButton) {
        performSegue(withIdentifier: "firstMenuPassPage", sender: self)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let firstPassPage = segue.destination as! ViewController
        firstPassPage.langFlag = langFlag
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
