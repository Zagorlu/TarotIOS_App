//
//  passViewController_1.swift
//  Tarot
//
//  Created by Emre Demirkol on 22.02.2018.
//  Copyright © 2018 Emre Demirkol. All rights reserved.
//

import UIKit

class passViewController_1: NSObject {

}
