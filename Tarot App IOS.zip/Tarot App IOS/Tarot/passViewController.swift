//
//  passViewController.swift
//  Tarot
//
//  Created by Emre Demirkol on 22.02.2018.
//  Copyright © 2018 Emre Demirkol. All rights reserved.
//

import Foundation
import UIKit

class passViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
