//
//  explainationViewController.swift
//  Tarot
//
//  Created by Emre Demirkol on 28.02.2018.
//  Copyright © 2018 Emre Demirkol. All rights reserved.
//

import UIKit



class explainationViewController: UIViewController {
    
    var index : Int = 0
    var langFlag : Bool = false
    var randomSelectedCards = [Int]()
    var cardsArray = [cardValues]()
    
    var m_cornerRadius : CGFloat = 10
    var m_borderWidth : CGFloat = 2
    var m_aplfaValue : CGFloat = 0.8

    @IBOutlet weak var cardsButton: UIButton!
    @IBOutlet weak var rightButton: UIButton!
    @IBOutlet weak var leftButton: UIButton!
    
    
    @IBOutlet weak var cardNameLabel: UILabel!
    @IBOutlet weak var imageBackground: UIImageView!
    @IBOutlet weak var shortImage: UIImageView!
    @IBOutlet weak var descriptionLabel: UITextView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.imageBackground.image = UIImage(named: cardsArray[randomSelectedCards[self.index]].imageName)
        self.shortImage.image = UIImage(named: cardsArray[randomSelectedCards[self.index]].imageName)
        cardNameLabel.text = cardsArray[randomSelectedCards[self.index]].cardName
        descriptionLabel.text = cardsArray[randomSelectedCards[self.index]].description
        
        //cardNameLabel.sizeToFit()
        //cardNameLabel.lineBreakMode = .byWordWrapping
        //cardNameLabel.numberOfLines = 0
        cardNameLabel.textAlignment = NSTextAlignment.center;
        cardNameLabel.font.withSize(32)
        cardNameLabel.layer.cornerRadius = 3
        cardNameLabel.layer.borderWidth = m_borderWidth
        cardNameLabel.backgroundColor = UIColor.init(white: 1, alpha: 0.8)
        cardNameLabel.font = UIFont(name:"HelveticaNeue-Bold", size: 20.0)

        
        //descriptionLabel.sizeToFit()
        //descriptionLabel.textAlignment = NSTextAlignment.center;
        //descriptionLabel.font.withSize(32)
        descriptionLabel.layer.cornerRadius = 3
        descriptionLabel.layer.borderWidth = m_borderWidth
        descriptionLabel.backgroundColor = UIColor.init(white: 1, alpha: 0.8)
        descriptionLabel.font = UIFont(name:"HelveticaNeue-Bold", size: 16.0)


        if langFlag == false
        {
            cardsButton.setImage(UIImage(named: "cards_eng.png"), for: .normal)
        }
        else
        {
            cardsButton.setImage(UIImage(named: "cards_tr.png"), for: .normal)
        }
        
        cardsButton.layer.cornerRadius = m_cornerRadius
        cardsButton.layer.borderWidth = m_borderWidth
        cardsButton.backgroundColor = UIColor.init(white: 1, alpha: m_aplfaValue)
        
        rightButton.layer.cornerRadius = m_cornerRadius
        rightButton.layer.borderWidth = m_borderWidth
        rightButton.backgroundColor = UIColor.init(white: 1, alpha: m_aplfaValue)
        
        leftButton.layer.cornerRadius = m_cornerRadius
        leftButton.layer.borderWidth = m_borderWidth
        leftButton.backgroundColor = UIColor.init(white: 1, alpha: m_aplfaValue)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    @IBAction func returnCards(_ sender: UIButton) {
        performSegue(withIdentifier: "cardsPassPage", sender: self)
    }
    @IBAction func rightCard(_ sender: UIButton) {
        if self.index != 6
        {
            self.index = self.index + 1
            viewDidLoad()
            leftButton.isHidden = false

        }
        if self.index == 6
        {
            rightButton.isHidden = true
            leftButton.isHidden = false
        }
    }
    @IBAction func leftCard(_ sender: UIButton) {
        if self.index != 0
        {
            self.index = self.index - 1
            viewDidLoad()
            rightButton.isHidden = false
            
        }
        if self.index == 0
        {
            leftButton.isHidden = true
            rightButton.isHidden = false
        }
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let firstPassPage = segue.destination as! selectedTableViewController
        firstPassPage.langFlag = langFlag
        firstPassPage.isFirstValue = false
        firstPassPage.randomSelectedCards = self.randomSelectedCards
    }
}
