//
//  firstPassViewController.swift
//  Tarot
//
//  Created by Emre Demirkol on 22.02.2018.
//  Copyright © 2018 Emre Demirkol. All rights reserved.
//

import UIKit

class firstPassViewController: UIViewController {
    
    var langFlag : Bool = false
    
    
    @IBOutlet weak var descLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if langFlag == false
        {
            descLabel.text = "Choose 7 cards that may suit you for the Tarot..."
        }
        else
        {
            descLabel.text = "Tarot Falınız için size uygun olabilecek 7 kart seçiniz..."
        }
        descLabel.textColor = UIColor.white
        descLabel.sizeToFit()
        descLabel.lineBreakMode = .byWordWrapping
        descLabel.numberOfLines = 0
        descLabel.textAlignment = NSTextAlignment.center;
        descLabel.font.withSize(32)
        descLabel.backgroundColor = UIColor.init(white: 0, alpha: 0.8)
        //descLabel.adjustsFontSizeToFitWidth = true
        //descLabel.textAlignment = NSTextAlignment.center
        //descLabel.center = self.view.center
        //self.view.addSubview(descLabel)
        
        
        
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        sleep(5)
        performSegue(withIdentifier: "secondPassPage", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let firstPassPage = segue.destination as! cardSelectionViewController
        firstPassPage.langFlag = langFlag
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}
